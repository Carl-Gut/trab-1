cons=float(input("Escriba cantidad de su consumo: "))
